// ===================  ======          ======
// ==================== ======        ======
//              ======  ======      ======
//            ======    ======    ======
//          ======      ======  ======
//        ======        ============
//      ======          ============
//    ======            ======  ======
//  ======              ======    ======
// ======               ======      ======
// ===================  ======        ======
// ==================== ======          ======
//
// DEVELOPED BY ZK#6666
package com.example.geoespacial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioButton at, aba, abv, n, f, v, h;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        getSupportActionBar().hide();
        at = findViewById(R.id.At);
        aba = findViewById(R.id.Aba);
        abv = findViewById(R.id.Abv);
        n = findViewById(R.id.Nl);
        f = findViewById(R.id.Af);
        v = findViewById(R.id.V);
        h = findViewById(R.id.H);

    }
    public void click(View view){
        Intent i = new Intent(this, telaCalculo.class);

        if(at.isChecked()){
            telaCalculo.formula = 1;
            startActivity(i);

        }
        else if(aba.isChecked()){
            telaCalculo.formula = 2; 
            startActivity(i);

        }
        else if(v.isChecked()){
            telaCalculo.formula = 6;
            startActivity(i);

        }
        else if(n.isChecked()){
            telaCalculo.formula = 5;
            startActivity(i);

        }
        else if(f.isChecked()){
            telaCalculo.formula = 4;
            startActivity(i);

        }
        else if(abv.isChecked()){
            telaCalculo.formula = 3;
            startActivity(i);

        }
        else if (h.isChecked()){
            telaCalculo.formula = 7;
            startActivity(i);

        }
        else{
            Toast.makeText(this, "Você precisa selecionar uma opção!", Toast.LENGTH_LONG).show();
        }
}
    }